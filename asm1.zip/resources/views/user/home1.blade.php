@include('layout.header')
@include('user.tintrongloai')
@include('layout.footer')