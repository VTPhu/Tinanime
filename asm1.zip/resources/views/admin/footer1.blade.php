
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="/assets/js/jquery.min.js"></script>
        <script src="/assets/js/bootstrap.min.js"></script>
        <script src="/assets/js/detect.js"></script>
        <script src="/assets/js/fastclick.js"></script>
        <script src="/assets/js/jquery.blockUI.js"></script>
        <script src="/assets/js/waves.js"></script>
        <script src="/assets/js/jquery.slimscroll.js"></script>
        <script src="/assets/js/jquery.scrollTo.min.js"></script>
        <script src="/../plugins/switchery/switchery.min.js"></script>

        <!-- Counter js  -->
        <script src="/../plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="/../plugins/counterup/jquery.counterup.min.js"></script>

        <!--Morris Chart-->
		<script src="/../plugins/morris/morris.min.js"></script>
		<script src="/../plugins/raphael/raphael-min.js"></script>

        <!-- Dashboard init -->
        <script src="/assets/pages/jquery.dashboard.js"></script>

        <!-- App js -->
        <script src="/assets/js/jquery.core.js"></script>
        <script src="/assets/js/jquery.app.js"></script>
        

    </body>
    
        
        <script type="text/javascript">
                function xoa(){
                    alert('Đã xóa thành công ');
                    
                }
                function update(){
                    alert('Đã sửa thành công ');
                    
                }
            </script>
        
    
</html>